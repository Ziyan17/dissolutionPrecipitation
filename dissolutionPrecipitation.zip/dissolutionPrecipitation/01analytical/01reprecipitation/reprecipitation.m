clc
clear all

tmax = 10000;
%%%% analytical %%%%%%%%%%
t = 0:10:tmax;
t_simulation = 200:200:tmax;

cInitial = 0;
h1Initial = 0.5e-5;
h2Initial = 0.5e-5;

[t, x] = ode45( @rhs, t, [cInitial; h1Initial; h2Initial]);


% fileID = fopen('analytical_t.txt','w');
% fprintf(fileID, '%f\n', t);
% fclose(fileID);
% 
% fileID = fopen('analytical_top.txt','w');
% fprintf(fileID, '%f %f %f\n', x);
% fclose(fileID);

simulation_bottom = load('results_bottom.txt');
simulation_top = load('results_top.txt');
simulation_concentration = load('results_concentration.txt');
simulation_concentration = simulation_concentration(20:20:1000);

simulation_h2 = (1.0 - simulation_bottom) * 3e-5/2;
simulation_h1 = (1.0 - simulation_top) * 3e-5/2;
% 
% simulation_refine = load('resultsRefine.txt') ;
% 
plot(t_simulation, simulation_h1, 'ro', 'markers',8, 'linewidth',1.5)
hold on
% plot(t_simulation, (-simulation_refine*2)/(hTotal-hInitial), 'b+', 'markers',8, 'linewidth',1.5)
plot(t, x(:, 2), 'k--', 'linewidth',2)

plot(t_simulation, simulation_h2, 'b+', 'markers',8, 'linewidth',1.5)

plot(t, x(:, 3), 'k', 'linewidth',2)

xlabel('$t $ (s)','FontSize',20,'Interpreter','latex');
ylabel('$h_s $ (m)','FontSize',20,'Interpreter','latex');

set(gca,'FontName','Times New Roman','FontSize',...
    20,'LineWidth',2,'Yscale','linear');
% text(150, 0.108, '$Da = 2 \times 10 ^{-4} $','FontSize',18,'Interpreter','latex');
legend('Dissolution, proposed model','Dissolution, analytical','Precipitation, proposed model','Precipitation, analytical','FontSize',14,'Interpreter','latex')
set(legend,'EdgeColor', 'none', 'Color', 'none','location','northwest')

%%%%%%%%% Figure %%%%%%%%%%
set(gcf, 'Units', 'centimeters',...
    'Position',[3 4 16 12],... % [left bottom width height]
    'PaperPositionMode', 'auto');
h=gcf;
pos = get(gcf, 'Position');
set(h,'PaperUnits','centimeters', 'PaperSize', pos(3:4));
print(h,'-dpdf', sprintf('./%s.pdf',mfilename));

% write results to txt
T = table(t, x);
writetable(T, 'analytical.txt','Delimiter',' ');

TT = table(t_simulation', simulation_concentration, simulation_h1, simulation_h2);
writetable(TT, 'simulation.txt','Delimiter',' ');
function dxdt = rhs(t, x) % x = [c; h1; h2], i.e. concentration, thickness 1 and thickness 2
    K = 1e-8;
    V = 0.05;
    H = 3e-5;
    ceq1 = 1; %for dissolution
    ceq2 = 0; %for precipitation

    dxdt1 = (K * (x(1) - ceq1) * (x(1) * V - 1.0) + K * (x(1) - ceq2) * (x(1) * V -1.0)) / (H - x(2) - x(3));
    dxdt2 = K * V * (x(1) - ceq1);
    dxdt3 = K * V * (x(1) - ceq2);
    dxdt = [dxdt1; dxdt2; dxdt3];
end